package com.ecommerce.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Single shared JDBC connection helper used by every DAO.
 *
 * IMPORTANT (team standard):
 *  - Everyone points at the SAME database: "ecommerce_project"
 *  - Update DB_USER / DB_PASSWORD below to match your local MySQL credentials.
 *  - Make sure mysql-connector-j-x.x.x.jar is on the classpath when compiling/running.
 */
public class DBConnection {

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/ecommerce_project?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Root@123";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC driver not found on classpath. " +
                    "Add mysql-connector-j jar to lib/ and include it with -cp.", e);
        }
    }

    private DBConnection() {
        // utility class, no instances
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
