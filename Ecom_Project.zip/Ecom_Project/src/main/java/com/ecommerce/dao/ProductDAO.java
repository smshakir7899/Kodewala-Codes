package com.ecommerce.dao;

import com.ecommerce.model.Product;
import com.ecommerce.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    /** View all available products (open to everyone, no login required). */
    public List<Product> viewProducts() throws SQLException {
        String sql = "SELECT * FROM products ORDER BY product_name";
        List<Product> products = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                products.add(mapRow(rs));
            }
        }
        return products;
    }

    /** Search products by (partial) name - no login required. */
    public List<Product> searchProduct(String nameKeyword) throws SQLException {
        String sql = "SELECT * FROM products WHERE product_name LIKE ? ORDER BY product_name";
        List<Product> products = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + nameKeyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    products.add(mapRow(rs));
                }
            }
        }
        return products;
    }

    /**
     * Exact (case-insensitive) name lookup - used when adding to cart, since the
     * team decided customers add items by product NAME rather than product ID.
     */
    public Product findProductByName(String productName) throws SQLException {
        String sql = "SELECT * FROM products WHERE LOWER(product_name) = LOWER(?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, productName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /**
     * Locks and reads current stock for a product WITHIN an existing transaction
     * (uses SELECT ... FOR UPDATE so concurrent orders can't oversell stock).
     * Caller owns the Connection and its commit/rollback.
     */
    public int getStockForUpdate(Connection conn, int productId) throws SQLException {
        String sql = "SELECT stock_quantity FROM products WHERE product_id = ? FOR UPDATE";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("stock_quantity");
                }
            }
        }
        throw new SQLException("Product not found: id=" + productId);
    }

    /** Reduces stock for one product WITHIN an existing transaction. */
    public void reduceStock(Connection conn, int productId, int quantity) throws SQLException {
        String sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, quantity);
            ps.setInt(2, productId);
            ps.executeUpdate();
        }
    }

    private Product mapRow(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setProductId(rs.getInt("product_id"));
        p.setProductName(rs.getString("product_name"));
        p.setDescription(rs.getString("description"));
        p.setPrice(rs.getBigDecimal("price"));
        p.setStockQuantity(rs.getInt("stock_quantity"));
        p.setCreatedAt(rs.getTimestamp("created_at"));
        p.setUpdatedAt(rs.getTimestamp("updated_at"));
        return p;
    }
}
