package com.ecommerce.dao;

import com.ecommerce.model.Cart;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    private final ProductDAO productDAO = new ProductDAO();
    private final CartDAO cartDAO = new CartDAO();

    /**
     * Places an order for everything currently in the customer's cart.
     *
     * All-or-nothing JDBC transaction:
     *   1. Lock + validate stock for every cart line (SELECT ... FOR UPDATE)
     *   2. Insert the order row
     *   3. Batch-insert all order_items
     *   4. Batch-reduce stock on products
     *   5. Clear the cart
     * If ANY step fails (including insufficient stock), everything rolls back
     * and no partial order is ever left in the database.
     *
     * @return the newly created order_id
     * @throws SQLException on DB error
     * @throws IllegalStateException if the cart is empty or stock is insufficient
     */
    public int placeOrder(int customerId) throws SQLException {
        Connection conn = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            List<Cart> cartItems = cartDAO.viewCart(conn, customerId);
            if (cartItems.isEmpty()) {
                throw new IllegalStateException("Cart is empty - nothing to order.");
            }

            // Step 1: validate stock for every line BEFORE touching anything else
            for (Cart item : cartItems) {
                int availableStock = productDAO.getStockForUpdate(conn, item.getProductId());
                if (availableStock < item.getQuantity()) {
                    throw new IllegalStateException("Insufficient stock for '" + item.getProductName() +
                            "'. Available: " + availableStock + ", requested: " + item.getQuantity());
                }
            }

            // Step 2: compute total and create the order row
            BigDecimal total = BigDecimal.ZERO;
            for (Cart item : cartItems) {
                total = total.add(item.getLineTotal());
            }

            int orderId;
            String orderSql = "INSERT INTO orders (customer_id, total_amount, order_status) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, customerId);
                ps.setBigDecimal(2, total);
                ps.setString(3, "ORDERED");
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (!rs.next()) {
                        throw new SQLException("Failed to create order.");
                    }
                    orderId = rs.getInt(1);
                }
            }

            // Step 3: batch insert order_items
            String itemSql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(itemSql)) {
                for (Cart item : cartItems) {
                    ps.setInt(1, orderId);
                    ps.setInt(2, item.getProductId());
                    ps.setInt(3, item.getQuantity());
                    ps.setBigDecimal(4, item.getPrice());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            // Step 4: reduce stock for each product
            for (Cart item : cartItems) {
                productDAO.reduceStock(conn, item.getProductId(), item.getQuantity());
            }

            // Step 5: clear the cart
            cartDAO.clearCart(conn, customerId);

            conn.commit();
            return orderId;

        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            if (e instanceof SQLException) {
                throw (SQLException) e;
            }
            if (e instanceof IllegalStateException) {
                throw (IllegalStateException) e;
            }
            throw new RuntimeException("Order placement failed.", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException closeEx) {
                    closeEx.printStackTrace();
                }
            }
        }
    }

    public List<Order> viewOrders(int customerId) throws SQLException {
        String sql = "SELECT * FROM orders WHERE customer_id = ? ORDER BY order_date DESC";
        List<Order> orders = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order o = new Order();
                    o.setOrderId(rs.getInt("order_id"));
                    o.setCustomerId(rs.getInt("customer_id"));
                    o.setTotalAmount(rs.getBigDecimal("total_amount"));
                    o.setOrderDate(rs.getTimestamp("order_date"));
                    o.setOrderStatus(rs.getString("order_status"));
                    o.setCreatedAt(rs.getTimestamp("created_at"));
                    o.setUpdatedAt(rs.getTimestamp("updated_at"));
                    orders.add(o);
                }
            }
        }
        return orders;
    }

    public List<OrderItem> viewOrderItems(int orderId) throws SQLException {
        String sql = "SELECT oi.*, p.product_name FROM order_items oi " +
                "JOIN products p ON oi.product_id = p.product_id " +
                "WHERE oi.order_id = ?";
        List<OrderItem> items = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderItem oi = new OrderItem();
                    oi.setOrderItemId(rs.getInt("order_item_id"));
                    oi.setOrderId(rs.getInt("order_id"));
                    oi.setProductId(rs.getInt("product_id"));
                    oi.setQuantity(rs.getInt("quantity"));
                    oi.setPrice(rs.getBigDecimal("price"));
                    oi.setProductName(rs.getString("product_name"));
                    items.add(oi);
                }
            }
        }
        return items;
    }
}
